# SoapUI installer module

*This is a submodule of [SoapUI project](../)*

This module is for creating installers and archives.