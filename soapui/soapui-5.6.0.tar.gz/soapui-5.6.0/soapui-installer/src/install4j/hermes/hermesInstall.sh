#!/bin/sh
../jre/bin/java -jar hermes-installer-1.14.jar script.xml
