Oh hi, so you want to create a non-cucumber integration test, eh?
-----------------------------------------------------------------

That's fine as well. Please organize it according to the following example structure based on feature:

    --src
    ----test
    ------java
    --------com
    ----------smartbear
    ------------soapui
    --------------other
    ----------------soap
    ------------------wsdl
    --------------------ImportWsdl.java
    ----------------rest
    ------------------wadl
    --------------------ImportWadl.java

**That's is!**