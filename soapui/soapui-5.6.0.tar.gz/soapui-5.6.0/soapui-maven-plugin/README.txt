SoapUI plugin for both maven 1.X and maven 2
--------------------------------------------
maven 1.X related files:
- project.xml
- plugin.jelly
- project.properties

Install by placing jar distribution in <maven repository>/eviware/plugins

maven 2.X related files:
- pom.xml
- src/main -> source code for Mojos
- src/test -> test project for maven2 plugin

